<?php include('conn.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>JustEat</title>
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	
	<script src="jquery.min.js"></script>
	<script src="bootstrap.min.js"></script>
</head>